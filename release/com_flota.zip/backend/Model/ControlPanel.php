<?php
namespace Majem\Flota\Admin\Model;

use FOF30\Model\Model;

class ControlPanel extends Model
{

}