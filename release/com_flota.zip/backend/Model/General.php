<?php
namespace Majem\Flota\Admin\Model;

use FOF30\Model\Model;

class General extends Model
{

}