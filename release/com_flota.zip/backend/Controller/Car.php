<?php

namespace Majem\Flota\Admin\Controller;

defined('_JEXEC') or die;

class Car extends \FOF30\Controller\DataController
{

}
