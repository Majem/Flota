<?php
/**
 * Created by PhpStorm.
 * User: m.maciejewski
 * Date: 06.12.2017
 * Time: 08:26
 */

namespace Majem\Flota\Admin\Controller;

use \FOF30\Controller\DataController;

defined('_JEXEC') or die;

class MailingCycle extends DataController
{

}