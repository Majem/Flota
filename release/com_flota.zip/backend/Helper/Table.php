<?php
/**
 * Created by PhpStorm.
 * User: m.maciejewski
 * Date: 24.11.2017
 * Time: 12:04
 */

namespace Majem\Flota\Admin\Helper;


class Table
{

}