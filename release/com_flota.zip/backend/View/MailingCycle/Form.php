<?php
namespace Majem\Flota\Admin\View\MailingCycle;


class Form extends \FOF30\View\DataView\Form
{
}