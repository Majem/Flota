<?php
namespace Majem\Flota\Admin\View\Company;

use Majem\Flota\Admin\Model\Company;

class Form extends \FOF30\View\DataView\Form
{
}