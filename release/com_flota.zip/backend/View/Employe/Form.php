<?php
namespace Majem\Flota\Admin\View\Employe;

use Majem\Flota\Admin\Model\Employe;


class Form extends \FOF30\View\DataView\Form
{
}