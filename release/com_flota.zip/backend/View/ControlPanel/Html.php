<?php
namespace Majem\Flota\Admin\View\ControlPanel;

use FOF30\View\DataView\Html as FOFHtml;
class Html extends FOFHtml
{

}